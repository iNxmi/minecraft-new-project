This datapack will stop the Floating Islands, added by the mod Explorations, from spawning in the world.
Make sure this datapack is loaded after the Explorations+ mod.

Datapack created by: Buecher_wurm
